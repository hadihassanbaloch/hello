def say_hello():
    return "Hello, world!"